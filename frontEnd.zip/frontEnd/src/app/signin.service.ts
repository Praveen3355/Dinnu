import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders,HttpParams} from  '@angular/common/http';
import { Observable } from 'rxjs';
import {UserAdmin} from '../app/interfaces';
@Injectable({
  providedIn: 'root'
})
export class SigninService {

  constructor(private http:HttpClient) { }

  
  
  //const options: { responseType: 'text' as 'text', withCredentials: true };

posting(add){
  return this.http.post("http://localhost:1214/login/",add,{responseType: 'text' as 'text'});
}

// sendParams(UserID):Observable<any[]>{
//   let val = new HttpParams().set("userid",UserID)
//   console.log(val);
//   return this.http.get<any[]>("http://10.230.174.247:1214/getPolicyList/",{params:val});
// }

}
