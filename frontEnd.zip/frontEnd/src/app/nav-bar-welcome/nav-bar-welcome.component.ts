import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar-welcome',
  templateUrl: './nav-bar-welcome.component.html',
  styleUrls: ['./nav-bar-welcome.component.css']
})
export class NavBarWelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
