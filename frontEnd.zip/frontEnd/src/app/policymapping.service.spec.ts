import { TestBed } from '@angular/core/testing';

import { PolicymappingService } from './policymapping.service';

describe('PolicymappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PolicymappingService = TestBed.get(PolicymappingService);
    expect(service).toBeTruthy();
  });
});
