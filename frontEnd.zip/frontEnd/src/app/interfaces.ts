export class userRegister  {

    firstName:string;
    lastName:String;
    dob:String;
    address:String;
    contactNo:String;
    emailId:String;
    qualification:String;
    salary:String;
    panNo:String;
    employerType:String;
   gender:string;
   hint:any;
   hintid:String;
   hintans:String;
    employer:String;
    passcode:String;
}

export class policyRegisterses{
    policyName:String;
    startDate:String;
    duration:String;
    intialDeposit:String;
   // t:String;
    company:object;
  // t1:String;
   type:object;
   policyType:string;
   termsPerYear:String;
   termAmount:String; 
   interest:String;
}

export class editPolicy{
    policyName:string;
    duration:string;
    policyType:string;
    startDate:string;
    termAmount:string;
    intialDeposit:string;
   type:object;
    
    interest:string;
    maturityAmount:string;
    termsPerYear:string;
    company:object;
   
    
    
}

export class searchPolicy{
    duration:String;
    company:object;
    policyType:String;
    
    policyName:String;
}

export class UserAdmin{
    user :String;
    pass:String;
}