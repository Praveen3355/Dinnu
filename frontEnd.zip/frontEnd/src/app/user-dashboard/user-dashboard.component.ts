import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {UserdashService} from '../userdash.service';
import * as $ from 'jquery';
@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css'],
  providers:[UserdashService]
})
export class UserDashboardComponent implements OnInit {
  userIds:string;
  obj:any=[];
  loadChild = false;
  constructor(private route:ActivatedRoute,private services:UserdashService,private router:Router) { }
  search:any=[];
  polID:any;
  result=false;
  btnValue:string;
  ngOnInit() {
    this.obj = [];
   this.userIds = this.route.snapshot.paramMap.get('userId');
   console.log(this.userIds);
   this.services.sendParams(this.userIds).subscribe((response) =>{
     this.obj = response;
     console.log(this.obj);
   });
   
  }

  call(){
     this.loadChild = true;
     this.result=true;
  }
  

  objs($event){
   this.search = $event;
//    $("button").click(function() {
//     this.fired_button = $(this).val();
//     console.log(this.fired_button);
// });
// var fired_button = $("button").val(); 
// console.log(fired_button);
  // this.polID = this.search[0].policyId; 
  //  console.log($event);
  //  console.log(this.search[0].policyId);
  }

   funcall(btn){
     this.btnValue = this.search[btn].policyId
     console.log(this.polID);
     this.router.navigate(['Conform',{ policyIds:this.btnValue,
      userid:this.userIds}]);
   }


}
