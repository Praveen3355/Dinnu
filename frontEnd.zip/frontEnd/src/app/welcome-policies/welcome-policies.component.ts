import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-policies',
  templateUrl: './welcome-policies.component.html',
  styleUrls: ['./welcome-policies.component.css']
})
export class WelcomePoliciesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
