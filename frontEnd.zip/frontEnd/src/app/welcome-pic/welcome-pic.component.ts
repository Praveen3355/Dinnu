import { Component, OnInit} from '@angular/core';
declare var showSlides: any;


@Component({ 
  selector: 'app-welcome-pic',
  templateUrl: './welcome-pic.component.html',
  styleUrls: ['./welcome-pic.component.css'],

})
export class WelcomePicComponent implements OnInit {

  ngOnInit() {
  new showSlides();
  }

  ngAfterViewInit(){
    
  
  }
}
