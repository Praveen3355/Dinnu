import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserdashService {

  constructor(private http:HttpClient) { }

  sendParams(UserID){
    let val = new HttpParams().set("userid",UserID)
   // console.log(val);
    return this.http.get("http://localhost:1214/we/",{params:val});
  }

}
