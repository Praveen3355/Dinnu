import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserRegisterService {

  constructor(private http:HttpClient) { }

  storeData(data){
    return this.http.post("http://localhost:1214/registernopass/",data,{responseType:'text' as 'text'});
  }
  
  storeData1(data){
    return this.http.post("http://localhost:1214/register/",data,{responseType:'text' as 'text'});
  }


}
