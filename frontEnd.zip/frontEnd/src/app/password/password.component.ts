import { Component, OnInit } from '@angular/core';
import { UserRegisterComponent } from '../user-register/user-register.component';
import { UserRegisterService } from '../user-register.service';
import { Router } from '@angular/router';
import { userRegister } from '../interfaces';
import swal from 'sweetalert';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {
pass1:string;
pass2:string;
user:UserRegisterComponent;
  constructor(private service:UserRegisterService,private route:Router) { }

  ngOnInit() {
  }
  
  Validation():void{
    console.log(sessionStorage.getItem('firstname'));
    if(this.pass1==this.pass2 && this.pass1.length>=5){
      const userRegis: userRegister = {
        firstName: sessionStorage.getItem('firstname'),
        lastName: sessionStorage.getItem('lastname'),
        dob: sessionStorage.getItem('dob'),
        address: sessionStorage.getItem('address'),
        contactNo: sessionStorage.getItem('contact'),
        emailId: sessionStorage.getItem('email'),
        qualification: sessionStorage.getItem('qualify'),
        salary: sessionStorage.getItem('salary'),
        panNo: sessionStorage.getItem('pan'),
        employerType: sessionStorage.getItem('emptype'),
        employer: sessionStorage.getItem('empl'),
        hintid:sessionStorage.getItem('hint'),
        hint:{"hintid":sessionStorage.getItem('hint')},
        hintans: sessionStorage.getItem('hintans'),
        gender:sessionStorage.getItem('gender'),
        passcode:this.pass1
  
      }
      //console.log(this.user.Question+"==="+this.user.hintId);
  this.service.storeData1(userRegis).subscribe((response)=>{
    this.user.str = response;
    this.user.msg(this.user.str);
console.log(response);
  });
  this.route.navigate(["Signin"]);
    }
    else if(this.pass1.length>=5 && this.pass1.length<=8){
      swal("passwords did not match");
   }
  }
  

}
