import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConformPageComponent } from './conform-page.component';

describe('ConformPageComponent', () => {
  let component: ConformPageComponent;
  let fixture: ComponentFixture<ConformPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConformPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConformPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
